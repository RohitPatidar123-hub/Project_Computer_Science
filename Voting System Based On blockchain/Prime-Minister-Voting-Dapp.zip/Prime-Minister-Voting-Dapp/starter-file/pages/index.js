import React from "react";

const index = () => {
  return <div>index</div>;
};

export default index;
