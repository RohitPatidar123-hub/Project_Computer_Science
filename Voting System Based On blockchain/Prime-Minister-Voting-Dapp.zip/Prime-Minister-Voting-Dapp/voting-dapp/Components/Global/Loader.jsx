import React from "react";

const Loader = () => {
  return (
    <div class="custom-loader-wrapper">
      <div class="custom-loader"></div>
    </div>
  );
};

export default Loader;
