import React from "react";

const Preloader = () => {
  return (
    <div class="preloader">
      <span class="loader"></span>
    </div>
  );
};

export default Preloader;
