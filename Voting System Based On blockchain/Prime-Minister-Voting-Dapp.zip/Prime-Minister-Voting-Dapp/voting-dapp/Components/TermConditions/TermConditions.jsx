import React from "react";

import Privacy from "./Privacy";
const TermConditions = () => {
  return (
    <>
      <Privacy />
    </>
  );
};

export default TermConditions;
